import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path

# ---------- 全局绘图样式（顶级期刊标准） ----------
plt.rcParams.update({
    'font.family': ['Times New Roman', 'Arial'],
    'font.size': 11,
    'axes.linewidth': 1.2,
    'axes.labelsize': 11,
    'axes.titlesize': 0,               # 禁止内置标题
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    'legend.fontsize': 10,
    'axes.spines.top': False,
    'axes.spines.right': False,
    'legend.frameon': False,
    'figure.facecolor': 'white',       # 画布纯白背景
})

# ---------- 数据 ----------
models = [
    'RF', 'RF+KB', 'XGBoost', 'LSTM', 'Transformer',
    'FRAA-Dyn', 'FRAA-TE', 'FRAA-KB', 'FRAA'
]

# 左轴指标：Log Loss（越低越好）
log_loss = [0.72, 0.65, 0.62, 0.60, 0.58, 0.53, 0.535, 0.55, 0.5163]
# 右轴指标：Recall@5（越高越好）
recall5  = [0.28, 0.32, 0.35, 0.37, 0.39, 0.40, 0.395, 0.38, 0.4185]

x = np.arange(len(models))
width = 0.35
offset = width / 2

# ---------- 创建双轴柱状图 ----------
# 稍高的画布给外部图例留足空间
fig, ax1 = plt.subplots(figsize=(6.8, 4.3), constrained_layout=True)

# 左轴：Log Loss
bars1 = ax1.bar(
    x - offset, log_loss, width,
    color='#2E86AB', edgecolor='black', linewidth=0.5,
    label='Log Loss (lower is better)'
)

ax1.set_ylabel('Log Loss', labelpad=8)
ax1.set_ylim(0.48, 0.80)     # 下界稍低，避免柱子触碰边界
ax1.set_yticks(np.arange(0.50, 0.81, 0.05))

# 右轴：Recall@5
ax2 = ax1.twinx()
bars2 = ax2.bar(
    x + offset, recall5, width,
    color='#F6AE2D', edgecolor='black', linewidth=0.5,
    label='Recall@5 (higher is better)'
)

ax2.set_ylabel('Recall@5', labelpad=8)
ax2.set_ylim(0.18, 0.52)
ax2.set_yticks(np.arange(0.20, 0.51, 0.05))

# x轴标签
ax1.set_xticks(x)
ax1.set_xticklabels(models, rotation=45, ha='right')
ax1.set_xlabel('Model', labelpad=8)

# 边框与网格
ax1.spines['top'].set_visible(False)
ax2.spines['top'].set_visible(False)
ax1.grid(True, axis='y', alpha=0.5, linestyle='--', color='#E0E0E0', linewidth=0.8)

# ---------- 图例（轴外部上方，不覆盖数据） ----------
handles1, labels1 = ax1.get_legend_handles_labels()
handles2, labels2 = ax2.get_legend_handles_labels()
handles = handles1 + handles2
labels = labels1 + labels2

# 向画布顶部微调，避免挤压主图区域
ax1.legend(
    handles, labels,
    loc='upper center',
    bbox_to_anchor=(0.5, 1.10),        # 比默认稍低一点，确保完全在画布内
    ncol=2,
    frameon=True,
    framealpha=0.95,
    edgecolor='#CCCCCC'
)

# ---------- 保存 ----------
output_path = Path(
    r'/app/output/figure_generation/5c9d5ad4-f623-451b-82ec-01683b1c4254'
    r'/workspace/figures/main_result/main_results_comparison.png'
)
output_path.parent.mkdir(parents=True, exist_ok=True)

plt.savefig(output_path, dpi=300, facecolor='white', bbox_inches='tight')
plt.close()